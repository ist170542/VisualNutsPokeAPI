package pt.db.interactionpokeapi.repository;

public class Repository {
}
