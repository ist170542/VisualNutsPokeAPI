package pt.db.interactionpokeapi.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.paging.LivePagedListBuilder;
import android.arch.paging.PagedList;
import android.support.annotation.NonNull;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import pt.db.interactionpokeapi.model.PokemonDataSource;
import pt.db.interactionpokeapi.model.PokemonDataSourceFactory;
import pt.db.interactionpokeapi.model.PokemonItem;

public class ListPokemonActivityViewModel extends AndroidViewModel {

//        PhotoRepository photoRepository;
        PokemonDataSourceFactory pokemonDataSourceFactory;
        MutableLiveData<PokemonDataSource> dataSourceMutableLiveData;
        Executor executor;
        LiveData<PagedList<PokemonItem>> pagedListLiveData;

        public ListPokemonActivityViewModel(@NonNull Application application) {
            super(application);

            pokemonDataSourceFactory = new PokemonDataSourceFactory();
            dataSourceMutableLiveData = pokemonDataSourceFactory.getMutableLiveData();

            PagedList.Config config = (new PagedList.Config.Builder())
                    .setEnablePlaceholders(true)
                    .setInitialLoadSizeHint(10)
                    .setPageSize(10)
                    .setPrefetchDistance(10)
                    .build();
            executor = Executors.newFixedThreadPool(5);
            pagedListLiveData = (new LivePagedListBuilder<Long,PokemonItem>(pokemonDataSourceFactory,config))
                    .setFetchExecutor(executor)
                    .build();


        }

        public LiveData<PagedList<PokemonItem>> getPagedListLiveData() {
            return pagedListLiveData;
        }
    }

