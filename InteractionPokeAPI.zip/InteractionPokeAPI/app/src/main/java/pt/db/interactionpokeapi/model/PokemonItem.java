package pt.db.interactionpokeapi.model;

import android.support.annotation.NonNull;
import android.support.v7.util.DiffUtil;

public class PokemonItem {

    private String name;
    private String url;
    private String photoURL;

    public PokemonItem() {
    }

    public static final DiffUtil.ItemCallback<PokemonItem> CALLBACK = new DiffUtil.ItemCallback<PokemonItem>() {
        @Override
        public boolean areItemsTheSame(@NonNull PokemonItem pokemon, @NonNull PokemonItem t1) {
            return pokemon.url.equals(t1.url);
        }

        @Override
        public boolean areContentsTheSame(@NonNull PokemonItem photos, @NonNull PokemonItem t1) {
            return true;
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPhotoURL() {
        return photoURL;
    }

    public void setPhotoURL(String photoURL) {
        this.photoURL = photoURL;
    }
}
