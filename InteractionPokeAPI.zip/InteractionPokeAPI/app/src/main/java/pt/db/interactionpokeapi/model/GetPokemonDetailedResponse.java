package pt.db.interactionpokeapi.model;

public class GetPokemonDetailedResponse {

    private int base_experience;
    private int height;
    private int id;
    private String name;
    private int order;
    private int weight;

    public GetPokemonDetailedResponse() {
    }
}
