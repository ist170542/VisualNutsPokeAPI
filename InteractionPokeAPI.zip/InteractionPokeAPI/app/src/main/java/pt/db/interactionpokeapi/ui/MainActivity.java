package pt.db.interactionpokeapi.ui;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.paging.PagedList;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import pt.db.interactionpokeapi.R;
import pt.db.interactionpokeapi.adapter.PokemonAdapter;
import pt.db.interactionpokeapi.model.PokemonItem;
import pt.db.interactionpokeapi.viewmodel.ListPokemonActivityViewModel;

public class MainActivity extends AppCompatActivity{

    ListPokemonActivityViewModel mainActivityViewModel;

    RecyclerView pokemonRecylerview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        mainActivityViewModel = ViewModelProviders.of(this).get(ListPokemonActivityViewModel.class);
//
//        pokemonRecylerview = findViewById(R.id.recylerview);
//
//        pokemonRecylerview.setLayoutManager(new GridLayoutManager(this,1));
//
//        PokemonAdapter photosAdapter = new PokemonAdapter(this);
//
//        mainActivityViewModel.getPagedListLiveData().observe(this, new Observer<PagedList<PokemonItem>>() {
//            @Override
//            public void onChanged(@Nullable PagedList<PokemonItem> pokemons) {
//                photosAdapter.submitList(pokemons);
//                pokemonRecylerview.setAdapter(photosAdapter);
//            }
//        });

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        AppBarConfiguration appBarConfiguration =
                new AppBarConfiguration.Builder(navController.getGraph()).build();





    }


}
